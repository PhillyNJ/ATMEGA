//
//  atsha204a_config.h
//  
//
//  Created by Philip Vallone on 8/23/19.
//

#ifndef atsha204a_config_h
#define atsha204a_config_h

#include "cryptoauthlib.h"

#include <stdio.h>
#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif
#endif /* atsha204a_config_h */
