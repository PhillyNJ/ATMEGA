//
//  ATSHA204A_Imp.h
//
//
//  Created by Philip Vallone on 8/23/19.
//

#ifndef ATSHA204A_Imp_h
#define ATSHA204A_Imp_h


#include <stdio.h>
#include "cryptoauthlib.h"
#include "atca_host.h"
#ifdef __cplusplus
extern "C" {
#endif


#define RET_ERR(status, message) {   if (status != ATCA_SUCCESS) {printf("- Error - " message ":");  parse_error(status); return; }}
#define CHECK_STATUS_MESS(status, message) { if (status != ATCA_SUCCESS)  {printf("- Error - " message ":");  parse_error(status); return status;} }
#define TEST_NOT_EQUAL(expected, actual, message) {if (expected == actual) { printf("- Error - " message );  return status; }}
#define RET_STATUS(status) { if (status != ATCA_SUCCESS)  { parse_error(status); return status;} }
#define CHECK_DEV_TYPE(ATCADeviceType) {if(devtype != ATECC508A && devtype != ATECC608A){status = ATCA_GEN_FAIL;CHECK_STATUS_MESS(status, "Dev Type not supported .");}}


struct sha204_details {
  uint8_t serial_number[9];
  uint8_t rev_num[4];
  uint8_t lock_value;
  uint8_t lock_config;
  uint8_t i2c_address;
  uint8_t chip_config;
  uint8_t check_mac_config;
  uint8_t otp_mode;
  uint8_t select_mode;
  uint8_t small_zone[4];

};
struct sha204_details myDetails;

ATCA_STATUS status;
ATCADeviceType devtype;

uint8_t write_data[ATCA_KEY_SIZE];
uint8_t read_data[ATCA_KEY_SIZE];
uint8_t sn[9];

ATCA_STATUS  atsha04a_print_sn(void);
ATCA_STATUS  atsha204a_personalize(void);
ATCA_STATUS  sha204_get_details(struct sha204_details *details);
ATCA_STATUS  sha204_print_slot_config(void);
ATCA_STATUS  sha204_parse_slot_config_section(uint8_t slot, uint8_t hi, uint8_t lower);
ATCA_STATUS  sha204a_write_otp_zone(uint8_t *data, uint8_t len, uint8_t block);
bool sha204_check_data_is_locked(void);
bool sha204_check_config_is_locked(void);

ATCA_STATUS  sha204_write_keys(uint8_t *root);
ATCA_STATUS  sha204_create_diverse_key(uint8_t *rootkey, uint16_t target, uint8_t *outkey, uint8_t padding);
ATCA_STATUS  sha204_validate_keys(uint8_t *root);

ATCA_STATUS  sha204_key_roll_example_validation(uint8_t *rootkey);
ATCA_STATUS  sha204_diverse_key_example(uint16_t target, uint8_t *mac, uint8_t padding);
ATCA_STATUS  sha204_validate_derived_key(uint8_t *root, uint8_t key_id, uint8_t padding, uint8_t *derived_key);
ATCA_STATUS  sha204_get_slot_config(uint8_t* config_data);

ATCA_STATUS  sha204_gendig_example(uint16_t target_key_id, uint16_t mac_key);

void sha204_compare_digests(uint8_t *dig1,uint8_t *dig2, int len);
// print functions

void print_buffer(uint8_t *buff, uint8_t size);
void print_raw_buffer(uint8_t *buff, uint8_t size);
void parse_error(uint8_t ret);
void print_slot_config_header(void);
void print_slot_config_footer(void);
void print_key_config_header(void);
void print_menu_header(void);
void print_menu(void);
void print_buffer_array(uint8_t *buff, uint8_t size);

#ifdef __cplusplus
}
#endif

#endif /* ATSHA204A_Imp_h */
